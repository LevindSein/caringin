<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block" id="success-alert">
    <strong>Sukses ! </strong><?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-block" id="error-alert"> 
    <strong>Maaf ! </strong><?php echo e($message); ?> 
</div>
<?php endif; ?>


<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-block" id="warning-alert">
	<strong>Warning ! </strong> <?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-block" id="warning-alert">	
	<strong>Info ! </strong><?php echo e($message); ?>

</div>
<?php endif; ?>

<script>
    $(document).ready(function () {
        $("#success-alert,#warning-alert,#error-alert,#info-alert")
            .fadeTo(2000, 1000)
            .slideUp(2000, function () {
                $("#success-alert,#warning-alert,#error-alert,#info-alert").slideUp(1000);
            });
    });
</script><?php /**PATH C:\xampp\htdocs\caringinfinal\resources\levindsein/message/flash-message.blade.php ENDPATH**/ ?>