<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aC51KOIG2SiCr6H8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AsqDCLusWPtPUTYW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/storelogin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::USY2x1gk3XZXlfv4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IeJx9aOLjveYq4HZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/printer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RJQp6M0XgCknbMGZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dR8wrEwigppzyC09',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/harian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.harian',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8D0xm7ALGnQ7L1MC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/utama' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PxmJojPstDMwip99',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/utama/bulan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tw4rEOpFEKmSwTT4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/sisa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iVZIPzEPIb5aawYE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/selesai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RIKU7yyCU4VLltRu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KXVcJCrvLyjkxWmC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/penerimaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LnEEUaBjCVOEWCs2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kasir/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keuangan/checkout/arsip' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MDKmdsoBklhho9t4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keuangan/data/tunggakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5xWTEnAFQ16WLOt8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keuangan/data/tagihan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CoFzsgUX1OLSCQ15',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keuangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keuangan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/layanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layanan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'layanan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/layanan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layanan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pedagang/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CYXrgk71BZ9rAvKC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pedagang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pedagang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha/rekap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dipz7YLtPySPebMe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VtnZzzAWxkUIFbGV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tempatusaha/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/neraca' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::84XE1gELA1dk1K9L',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GvzWRPyr8h6DJmgV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/sinkronisasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5FAPYZESwJcII0cK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/periode' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zwixFBxmUsNgFslV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/tambah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xCP3mohv580KmQsn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/publish' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DHxWlHdHvEUzQ92u',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YqDNHXwBVcoEPC3O',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/review' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ABtxAcaQH9Lp1brh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/notification' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GT9sAl6hqsNTopb5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/listrik' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'listrik',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mtbSKQFF1xwhyRpr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/airbersih' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'airbersih',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YvurBOLWkWyjukUa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/print' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cs6spEkHjWfQUrB3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z1nnHjcJRcTZWBL5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tagihan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tagihan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tagihan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tagihan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pemakaian' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SRxWn0tHYHHFsckn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan/tahunan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bp5VLRI1G9uIROfr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan/bulanan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nU8vk0lfGxNbhy92',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rekap/pendapatan/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/datausaha/penghapusan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CrJ0RBPiduSdskPX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/datausaha/bongkaran' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eXyxLq2Tkk7rKYZf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/datausaha/tunggakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yEe2LxTKMNCpBOld',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/datausaha' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'datausaha.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'datausaha.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/datausaha/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'datausaha.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KkmheCf9MsSgUj2B',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/keamananipk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZwPv07ettsSrI7JQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/kebersihan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TECY3VAAvc7PJyxK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/airkotor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aWhsM4ZIZ2EV8vrx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/lain' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kpNhER2h70hSZjDj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lAIQkCaK8atee1u6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/tarif/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KbP8BcwGyXj3AiGo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FfWfLuVmxksA516j',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter/air' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HaRdVjSXvw2sg3KF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Kyqkm3Z7dBDt777a',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/alatmeter/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0HVzbwjPnGZilnGo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/harilibur' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AwXaRDhrHNkksXEs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/harilibur/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oznlCEzuDlrR31CN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/harilibur/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ud5J2DirbGodlbwo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/blok' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yxf4WajUm7GxaoxR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/blok/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tiL50ldnw4gJ94dq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/blok/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4WowXr6Py6JiwMb8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/utilities/simulasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vmInFSfhd5pTvLV6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KNkpR17ytXT6egkA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master/kasir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fsg7lo1wm3SflPgs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/master/kasir/edit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pcYA79U2bjOdF7PU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hpjgZOnxtIjvdYBw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/otoritas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rn3zKC3OCqoMGlx6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/manajer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3DQ8wiqny5Ha9du4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/keuangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NvwjrhgKldAuMhOx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/kasir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TfJJDbd2DB2DKLRw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/nasabah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7aHYBbVWz1TfBbwo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'user.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/log' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::78VmUfTCgi8v7EqW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/blok' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FYUNnRqREBo4uWhf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/nasabah' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bNOQhfkrC52O9fjN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alamat' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g68Sy4gN8TByqWiY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alamat/kosong' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AzGfRA5Z8HldLjn6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alatlistrik' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tmWD3Gahk2CWvpxx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cari/alatair' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3zXqJmwPvNxEwwl8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/work' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gPca4IixUyKIKrWY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/work/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n0nfFiPPKIku8R1m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/download' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xtQpdrdV9JhcaS8k',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/optimize.p3cmaster' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1dnjbFKynhsDZQGv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/t(?|e(?|st/data/([^/]++)(*:32)|mpatusaha/(?|qr/([^/]++)(*:63)|rekap/([^/]++)(*:84)|fasilitas/([^/]++)(*:109)|destroy/([^/]++)(*:133)|([^/]++)(?|(*:152)|/edit(*:165)|(*:173))))|agihan/(?|manual/([^/]++)(*:209)|pe(?|mb(?|eritahuan/([^/]++)(*:245)|ayaran/([^/]++)(*:268))|san/([^/]++)(*:289))|unpublish/([^/]++)(*:316)|review/([^/]++)(*:339)|destroy/(?|edit/([^/]++)(*:371)|([^/]++)(*:387))|([^/]++)(?|(*:407)|/edit(*:420)|(*:428))))|/k(?|asir/(?|harian/(?|([^/]++)(*:470)|pen(?|dapatan(*:491)|erimaan(*:506)))|mode/([^/]++)(*:529)|r(?|estore/([^/]++)(*:556)|incian/([^/]++)(*:579))|struk/([^/]++)(?|(*:605)|/([^/]++)(*:622))|bayar/([^/]++)(*:645)|([^/]++)(?|(*:664)|/edit(*:677)|(*:685)))|euangan/(?|laporan/(?|rekap/(?|generate/([^/]++)(*:743)|([^/]++)(*:759))|pendapatan/(?|generate/([^/]++)(*:799)|([^/]++)(*:815))|tagihan/(?|generate/([^/]++)(*:852)|([^/]++)(*:868)))|([^/]++)(?|(*:889)|/edit(*:902)|(*:910))))|/layanan/(?|tempat/([^/]++)(*:948)|([^/]++)(?|(*:967)|/edit(*:980)|(*:988)))|/pedagang/(?|destroy/([^/]++)(*:1027)|([^/]++)(?|(*:1047)|/edit(*:1061)|(*:1070)))|/rekap/pe(?|makaian/([^/]++)/([^/]++)(*:1118)|ndapatan/([^/]++)(?|(*:1147)|/edit(*:1161)|(*:1170)))|/datausaha/([^/]++)(?|(*:1203)|/edit(*:1217)|(*:1226))|/u(?|tilities/(?|tarif/(?|edit/([^/]++)/([^/]++)(*:1284)|destroy/([^/]++)/([^/]++)(*:1318))|alatmeter/(?|edit/([^/]++)/([^/]++)(*:1363)|destroy/([^/]++)/([^/]++)(*:1397)|qr/([^/]++)/([^/]++)(*:1426))|harilibur/(?|edit/([^/]++)(*:1462)|destroy/([^/]++)(*:1487))|blok/(?|edit/([^/]++)(*:1518)|destroy/([^/]++)(*:1543)))|ser/(?|destroy/([^/]++)(*:1577)|reset/([^/]++)(*:1600)|([^/]++)(?|/(?|otoritas(*:1632)|edit(*:1645))|(*:1655))))|/master/kasir/(?|restore/([^/]++)(*:1700)|struk/([^/]++)/([^/]++)(*:1732))|/cari/(?|tagihan/([^/]++)(?|(*:1770)|/([^/]++)(*:1788))|l(?|istrik/([^/]++)(*:1817)|ain/([^/]++)(*:1838))|air(?|bersih/([^/]++)(*:1869)|kotor/([^/]++)(*:1892))|ke(?|amananipk/([^/]++)(*:1925)|bersihan/([^/]++)(*:1951))))/?$}sDu',
    ),
    3 => 
    array (
      32 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A8sit8Y4Y1PVHw03',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      63 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UX7o9pqp1mCAwrhu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      84 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CMcoo5tOADKccnhO',
          ),
          1 => 
          array (
            0 => 'blok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      109 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qfYKRTW97FkEjjBJ',
          ),
          1 => 
          array (
            0 => 'fas',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      133 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::afAdMRdEyzqUCTYK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      152 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.show',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.edit',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.update',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tempatusaha.destroy',
          ),
          1 => 
          array (
            0 => 'tempatusaha',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      209 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f6TVnnpUHRWAu2n6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      245 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zmRdelKaBIeRIEXY',
          ),
          1 => 
          array (
            0 => 'blok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      268 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9d9hHt9CztsplyCf',
          ),
          1 => 
          array (
            0 => 'blok',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LVfgNYmzCKJ8LKv8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::txPyMsmFb4d0zM5j',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      339 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C3NJwAjxLyROlB6k',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l5wgezF5iXFgLVPK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ckqZ6yVBziTYwDjl',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tagihan.show',
          ),
          1 => 
          array (
            0 => 'tagihan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      420 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tagihan.edit',
          ),
          1 => 
          array (
            0 => 'tagihan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      428 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tagihan.update',
          ),
          1 => 
          array (
            0 => 'tagihan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tagihan.destroy',
          ),
          1 => 
          array (
            0 => 'tagihan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      470 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l7i2yfyfI9c6hbqh',
          ),
          1 => 
          array (
            0 => 'val',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      491 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9YBqlFORZLfCOpSe',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      506 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FE9247NNKShZnfl1',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      529 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xd0iz4ulhf6MiuJE',
          ),
          1 => 
          array (
            0 => 'mode',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      556 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XfxEsbGfIdZOj2EY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      579 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YDSLp16lZVOR0zic',
          ),
          1 => 
          array (
            0 => 'kontrol',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      605 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zvAOCHrI4NlMfnko',
          ),
          1 => 
          array (
            0 => 'struk',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      622 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EuGn3LNz4H0C9XTx',
          ),
          1 => 
          array (
            0 => 'struk',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      645 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fSKUabFDNRYqRvu0',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      664 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.show',
          ),
          1 => 
          array (
            0 => 'kasir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      677 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.edit',
          ),
          1 => 
          array (
            0 => 'kasir',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      685 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.update',
          ),
          1 => 
          array (
            0 => 'kasir',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'kasir.destroy',
          ),
          1 => 
          array (
            0 => 'kasir',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      743 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rVPYaI341waSHJi5',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      759 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YaFIIZf47af8EtTs',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      799 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3qKKWWbsTJBEz4Qp',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      815 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W9qNeK0LC78GDLWI',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      852 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hJpMvYbTpoxa0Tgg',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      868 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CY1TZENHITlEUifU',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      889 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.show',
          ),
          1 => 
          array (
            0 => 'keuangan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      902 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.edit',
          ),
          1 => 
          array (
            0 => 'keuangan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      910 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.update',
          ),
          1 => 
          array (
            0 => 'keuangan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'keuangan.destroy',
          ),
          1 => 
          array (
            0 => 'keuangan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SxcrqOPuc756jOto',
          ),
          1 => 
          array (
            0 => 'data',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      967 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layanan.show',
          ),
          1 => 
          array (
            0 => 'layanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      980 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layanan.edit',
          ),
          1 => 
          array (
            0 => 'layanan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      988 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layanan.update',
          ),
          1 => 
          array (
            0 => 'layanan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'layanan.destroy',
          ),
          1 => 
          array (
            0 => 'layanan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1027 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j7UBdOcH65u4fXlo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1047 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.show',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1061 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.edit',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1070 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.update',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pedagang.destroy',
          ),
          1 => 
          array (
            0 => 'pedagang',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1118 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1V9VToo6GMmAdi0c',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'bulan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.show',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1161 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.edit',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.update',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'pendapatan.destroy',
          ),
          1 => 
          array (
            0 => 'pendapatan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1203 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'datausaha.show',
          ),
          1 => 
          array (
            0 => 'datausaha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'datausaha.edit',
          ),
          1 => 
          array (
            0 => 'datausaha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1226 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'datausaha.update',
          ),
          1 => 
          array (
            0 => 'datausaha',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'datausaha.destroy',
          ),
          1 => 
          array (
            0 => 'datausaha',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1284 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B8siwiSH72H22Dp3',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1318 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::86JqXL8OhpOFISHR',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1363 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8mw9TleSfzEVx4Xp',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1397 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lE3iP5NJAkJP4ruR',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eSJxcaaiS2xjLJ57',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1462 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aI3A6yln0rvO3iEg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1487 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::723VbUOfuzO9Oxhv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1518 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f3BTBOs06QAsy8N5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0jTvthuW51lPS9qu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1577 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MNDFuxjDhEkp1Af0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1600 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9yabRBW5kugwNYw6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1632 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RjleNt8P3Cy6kvm4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1645 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.edit',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1655 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'user.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'user.destroy',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1700 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4K5lJTUHmwE3mLRr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1732 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::x7Pb98S75erhpxgf',
          ),
          1 => 
          array (
            0 => 'struk',
            1 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1770 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M3fvRT6gwyPRAcQs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1788 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::98sLsMZlgYktr70h',
          ),
          1 => 
          array (
            0 => 'fasilitas',
            1 => 'kontrol',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1817 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c9vZpWmACmcd6Lrm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1838 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J5YPU3p4PRawfESi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1869 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UyJvYsm04pFrZbsh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1892 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9Tl8NCeIFGyuEPoJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1925 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::skoW2uY5rKLUnD66',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1951 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tT46gzQkbgVNpNQj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::aC51KOIG2SiCr6H8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":289:{@SlegejtodvtSOgCs2eZeykm8eqtaz04nOATbHmRXxVc=.a:5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed6bb0000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::aC51KOIG2SiCr6H8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AsqDCLusWPtPUTYW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":265:{@NC3vydSXueAOhtEqQ+j/rkFibFlPVCDBvVu2aZbi3lY=.a:5:{s:3:"use";a:0:{}s:8:"function";s:53:"function(){
    return \\redirect()->route(\'login\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed6b90000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AsqDCLusWPtPUTYW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":1265:{@GH8qZUjGl+ua7puAvUZzw41U8fa7+3aLAhPIOwlL0js=.a:5:{s:3:"use";a:0:{}s:8:"function";s:1051:"function(){
    $time = "unknown";
    $now = \\Carbon\\Carbon::now();
    $start = \\Carbon\\Carbon::createFromTimeString(\'04:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'10:00\');
    if ($now->between($start, $end)){
        $time = "pagi";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'10:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'15:00\');
    if ($now->between($start, $end)){
        $time = "siang";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'15:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'19:00\');
    if ($now->between($start, $end)){
        $time = "sore";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'19:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'23:59\');
    if ($now->between($start, $end)){
        $time = "malam";
    }
    $start = \\Carbon\\Carbon::createFromTimeString(\'00:00\');
    $end = \\Carbon\\Carbon::createFromTimeString(\'04:00\');
    if ($now->between($start, $end)){
        $time = "malam";
    }
    return \\view(\'home.login\',[\'time\'=>$time]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed6bf0000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::USY2x1gk3XZXlfv4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'storelogin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:home',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":1091:{@U19FNwSA5QLyUFU/v2imNxf1L0ocHPNSZcBWcEdm3jM=.a:5:{s:3:"use";a:0:{}s:8:"function";s:878:"function(\\Illuminate\\Http\\Request $request){
    try{
        if(\\csrf_token() === $request->_token){
            if($request->role === \'master\')
                return \\redirect()->route(\'dashboard\')->with(\'success\',\'Selamat Datang Master\');
            else if($request->role === \'manajer\')
                return \\redirect()->route(\'dashboard\')->with(\'success\',\'Selamat Datang Manajer\');
            else if($request->role === \'kasir\')
                return \\redirect()->route(\'kasir.index\');
            else if($request->role === \'admin\')
                return \\redirect()->route(\'dashboard\')->with(\'success\',"Selamat Datang $request->nama");
            else if($request->role === \'keuangan\')
                return \\redirect()->route(\'keuangan.index\');
            else
                \\abort(404);
        }
    }
    catch(\\Exception $e){
        \\abort(404);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed6bd0000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::USY2x1gk3XZXlfv4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::IeJx9aOLjveYq4HZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":385:{@7bCG+Z8ATwLfRwxovUz53wneMYAvkMl4KKVSKjJWv6I=.a:5:{s:3:"use";a:0:{}s:8:"function";s:172:"function(){
    \\Illuminate\\Support\\Facades\\Session::flush();
    \\Artisan::call(\'cache:clear\');
    return \\redirect()->route(\'login\')->with(\'success\',\'Sampai Bertemu\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed6b30000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::IeJx9aOLjveYq4HZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:dashboard',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::A8sit8Y4Y1PVHw03' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'test/data/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@testdata',
        'controller' => 'App\\Http\\Controllers\\KasirController@testdata',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::A8sit8Y4Y1PVHw03',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RJQp6M0XgCknbMGZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kasir/printer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@printer',
        'controller' => 'App\\Http\\Controllers\\KasirController@printer',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RJQp6M0XgCknbMGZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::l7i2yfyfI9c6hbqh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kasir/harian/{val}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@harianval',
        'controller' => 'App\\Http\\Controllers\\KasirController@harianval',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::l7i2yfyfI9c6hbqh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dR8wrEwigppzyC09' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@settings',
        'controller' => 'App\\Http\\Controllers\\KasirController@settings',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::dR8wrEwigppzyC09',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9YBqlFORZLfCOpSe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/harian/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@harianpendapatan',
        'controller' => 'App\\Http\\Controllers\\KasirController@harianpendapatan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9YBqlFORZLfCOpSe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FE9247NNKShZnfl1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/harian/penerimaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@harianpenerimaan',
        'controller' => 'App\\Http\\Controllers\\KasirController@harianpenerimaan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::FE9247NNKShZnfl1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.harian' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/harian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@harian',
        'controller' => 'App\\Http\\Controllers\\KasirController@harian',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'kasir.harian',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8D0xm7ALGnQ7L1MC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kasir/harian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@harianpost',
        'controller' => 'App\\Http\\Controllers\\KasirController@harianpost',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8D0xm7ALGnQ7L1MC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Xd0iz4ulhf6MiuJE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/mode/{mode}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@mode',
        'controller' => 'App\\Http\\Controllers\\KasirController@mode',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Xd0iz4ulhf6MiuJE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::PxmJojPstDMwip99' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/utama',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@getutama',
        'controller' => 'App\\Http\\Controllers\\KasirController@getutama',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::PxmJojPstDMwip99',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tw4rEOpFEKmSwTT4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/utama/bulan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@getutamaBulan',
        'controller' => 'App\\Http\\Controllers\\KasirController@getutamaBulan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tw4rEOpFEKmSwTT4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::iVZIPzEPIb5aawYE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/sisa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@getsisa',
        'controller' => 'App\\Http\\Controllers\\KasirController@getsisa',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::iVZIPzEPIb5aawYE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RIKU7yyCU4VLltRu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/selesai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@getselesai',
        'controller' => 'App\\Http\\Controllers\\KasirController@getselesai',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RIKU7yyCU4VLltRu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KXVcJCrvLyjkxWmC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@restore',
        'controller' => 'App\\Http\\Controllers\\KasirController@restore',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KXVcJCrvLyjkxWmC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::XfxEsbGfIdZOj2EY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kasir/restore/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@restoreStore',
        'controller' => 'App\\Http\\Controllers\\KasirController@restoreStore',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::XfxEsbGfIdZOj2EY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zvAOCHrI4NlMfnko' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/struk/{struk}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@struk',
        'controller' => 'App\\Http\\Controllers\\KasirController@struk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::zvAOCHrI4NlMfnko',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::EuGn3LNz4H0C9XTx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/struk/{struk}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@cetakStruk',
        'controller' => 'App\\Http\\Controllers\\KasirController@cetakStruk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::EuGn3LNz4H0C9XTx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LnEEUaBjCVOEWCs2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/penerimaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@penerimaan',
        'controller' => 'App\\Http\\Controllers\\KasirController@penerimaan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::LnEEUaBjCVOEWCs2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::fSKUabFDNRYqRvu0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/bayar/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@bayar',
        'controller' => 'App\\Http\\Controllers\\KasirController@bayar',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::fSKUabFDNRYqRvu0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YDSLp16lZVOR0zic' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/rincian/{kontrol}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'uses' => 'App\\Http\\Controllers\\KasirController@rincian',
        'controller' => 'App\\Http\\Controllers\\KasirController@rincian',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YDSLp16lZVOR0zic',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'as' => 'kasir.index',
        'uses' => 'App\\Http\\Controllers\\KasirController@index',
        'controller' => 'App\\Http\\Controllers\\KasirController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'as' => 'kasir.create',
        'uses' => 'App\\Http\\Controllers\\KasirController@create',
        'controller' => 'App\\Http\\Controllers\\KasirController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kasir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'as' => 'kasir.store',
        'uses' => 'App\\Http\\Controllers\\KasirController@store',
        'controller' => 'App\\Http\\Controllers\\KasirController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/{kasir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'as' => 'kasir.show',
        'uses' => 'App\\Http\\Controllers\\KasirController@show',
        'controller' => 'App\\Http\\Controllers\\KasirController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kasir/{kasir}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'as' => 'kasir.edit',
        'uses' => 'App\\Http\\Controllers\\KasirController@edit',
        'controller' => 'App\\Http\\Controllers\\KasirController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'kasir/{kasir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'as' => 'kasir.update',
        'uses' => 'App\\Http\\Controllers\\KasirController@update',
        'controller' => 'App\\Http\\Controllers\\KasirController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'kasir.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kasir/{kasir}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:kasir',
        ),
        'as' => 'kasir.destroy',
        'uses' => 'App\\Http\\Controllers\\KasirController@destroy',
        'controller' => 'App\\Http\\Controllers\\KasirController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MDKmdsoBklhho9t4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/checkout/arsip',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@arsip',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@arsip',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::MDKmdsoBklhho9t4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5xWTEnAFQ16WLOt8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/data/tunggakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@dataTunggakan',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@dataTunggakan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5xWTEnAFQ16WLOt8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CoFzsgUX1OLSCQ15' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/data/tagihan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@dataTagihan',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@dataTagihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::CoFzsgUX1OLSCQ15',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rVPYaI341waSHJi5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/laporan/rekap/generate/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@lapGenerateRekap',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@lapGenerateRekap',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::rVPYaI341waSHJi5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YaFIIZf47af8EtTs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/laporan/rekap/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@lapRekap',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@lapRekap',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YaFIIZf47af8EtTs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3qKKWWbsTJBEz4Qp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/laporan/pendapatan/generate/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@lapGeneratePendapatan',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@lapGeneratePendapatan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3qKKWWbsTJBEz4Qp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::W9qNeK0LC78GDLWI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/laporan/pendapatan/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@lapPendapatan',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@lapPendapatan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::W9qNeK0LC78GDLWI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hJpMvYbTpoxa0Tgg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/laporan/tagihan/generate/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@lapGenerateTagihan',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@lapGenerateTagihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hJpMvYbTpoxa0Tgg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CY1TZENHITlEUifU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/laporan/tagihan/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'uses' => 'App\\Http\\Controllers\\KeuanganController@lapTagihan',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@lapTagihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::CY1TZENHITlEUifU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'as' => 'keuangan.index',
        'uses' => 'App\\Http\\Controllers\\KeuanganController@index',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'as' => 'keuangan.create',
        'uses' => 'App\\Http\\Controllers\\KeuanganController@create',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'as' => 'keuangan.store',
        'uses' => 'App\\Http\\Controllers\\KeuanganController@store',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/{keuangan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'as' => 'keuangan.show',
        'uses' => 'App\\Http\\Controllers\\KeuanganController@show',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keuangan/{keuangan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'as' => 'keuangan.edit',
        'uses' => 'App\\Http\\Controllers\\KeuanganController@edit',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'keuangan/{keuangan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'as' => 'keuangan.update',
        'uses' => 'App\\Http\\Controllers\\KeuanganController@update',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'keuangan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'keuangan/{keuangan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:keuangan',
        ),
        'as' => 'keuangan.destroy',
        'uses' => 'App\\Http\\Controllers\\KeuanganController@destroy',
        'controller' => 'App\\Http\\Controllers\\KeuanganController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SxcrqOPuc756jOto' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'layanan/tempat/{data}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'uses' => 'App\\Http\\Controllers\\LayananController@tempat',
        'controller' => 'App\\Http\\Controllers\\LayananController@tempat',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SxcrqOPuc756jOto',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'layanan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'layanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'as' => 'layanan.index',
        'uses' => 'App\\Http\\Controllers\\LayananController@index',
        'controller' => 'App\\Http\\Controllers\\LayananController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'layanan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'layanan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'as' => 'layanan.create',
        'uses' => 'App\\Http\\Controllers\\LayananController@create',
        'controller' => 'App\\Http\\Controllers\\LayananController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'layanan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'layanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'as' => 'layanan.store',
        'uses' => 'App\\Http\\Controllers\\LayananController@store',
        'controller' => 'App\\Http\\Controllers\\LayananController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'layanan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'layanan/{layanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'as' => 'layanan.show',
        'uses' => 'App\\Http\\Controllers\\LayananController@show',
        'controller' => 'App\\Http\\Controllers\\LayananController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'layanan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'layanan/{layanan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'as' => 'layanan.edit',
        'uses' => 'App\\Http\\Controllers\\LayananController@edit',
        'controller' => 'App\\Http\\Controllers\\LayananController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'layanan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'layanan/{layanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'as' => 'layanan.update',
        'uses' => 'App\\Http\\Controllers\\LayananController@update',
        'controller' => 'App\\Http\\Controllers\\LayananController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'layanan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'layanan/{layanan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:layanan',
        ),
        'as' => 'layanan.destroy',
        'uses' => 'App\\Http\\Controllers\\LayananController@destroy',
        'controller' => 'App\\Http\\Controllers\\LayananController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CYXrgk71BZ9rAvKC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pedagang/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'uses' => 'App\\Http\\Controllers\\PedagangController@update',
        'controller' => 'App\\Http\\Controllers\\PedagangController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::CYXrgk71BZ9rAvKC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::j7UBdOcH65u4fXlo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'uses' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'controller' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::j7UBdOcH65u4fXlo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.index',
        'uses' => 'App\\Http\\Controllers\\PedagangController@index',
        'controller' => 'App\\Http\\Controllers\\PedagangController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.create',
        'uses' => 'App\\Http\\Controllers\\PedagangController@create',
        'controller' => 'App\\Http\\Controllers\\PedagangController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pedagang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.store',
        'uses' => 'App\\Http\\Controllers\\PedagangController@store',
        'controller' => 'App\\Http\\Controllers\\PedagangController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/{pedagang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.show',
        'uses' => 'App\\Http\\Controllers\\PedagangController@show',
        'controller' => 'App\\Http\\Controllers\\PedagangController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pedagang/{pedagang}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.edit',
        'uses' => 'App\\Http\\Controllers\\PedagangController@edit',
        'controller' => 'App\\Http\\Controllers\\PedagangController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'pedagang/{pedagang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.update',
        'uses' => 'App\\Http\\Controllers\\PedagangController@update',
        'controller' => 'App\\Http\\Controllers\\PedagangController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pedagang.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'pedagang/{pedagang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pedagang',
        ),
        'as' => 'pedagang.destroy',
        'uses' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'controller' => 'App\\Http\\Controllers\\PedagangController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UX7o9pqp1mCAwrhu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/qr/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@qr',
        'controller' => 'App\\Http\\Controllers\\TempatController@qr',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::UX7o9pqp1mCAwrhu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Dipz7YLtPySPebMe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/rekap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@rekap',
        'controller' => 'App\\Http\\Controllers\\TempatController@rekap',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Dipz7YLtPySPebMe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CMcoo5tOADKccnhO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/rekap/{blok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@rekapdetail',
        'controller' => 'App\\Http\\Controllers\\TempatController@rekapdetail',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::CMcoo5tOADKccnhO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::qfYKRTW97FkEjjBJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/fasilitas/{fas}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@fasilitas',
        'controller' => 'App\\Http\\Controllers\\TempatController@fasilitas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::qfYKRTW97FkEjjBJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::VtnZzzAWxkUIFbGV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tempatusaha/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@update',
        'controller' => 'App\\Http\\Controllers\\TempatController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::VtnZzzAWxkUIFbGV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::afAdMRdEyzqUCTYK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'uses' => 'App\\Http\\Controllers\\TempatController@destroy',
        'controller' => 'App\\Http\\Controllers\\TempatController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::afAdMRdEyzqUCTYK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.index',
        'uses' => 'App\\Http\\Controllers\\TempatController@index',
        'controller' => 'App\\Http\\Controllers\\TempatController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.create',
        'uses' => 'App\\Http\\Controllers\\TempatController@create',
        'controller' => 'App\\Http\\Controllers\\TempatController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tempatusaha',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.store',
        'uses' => 'App\\Http\\Controllers\\TempatController@store',
        'controller' => 'App\\Http\\Controllers\\TempatController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/{tempatusaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.show',
        'uses' => 'App\\Http\\Controllers\\TempatController@show',
        'controller' => 'App\\Http\\Controllers\\TempatController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tempatusaha/{tempatusaha}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.edit',
        'uses' => 'App\\Http\\Controllers\\TempatController@edit',
        'controller' => 'App\\Http\\Controllers\\TempatController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'tempatusaha/{tempatusaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.update',
        'uses' => 'App\\Http\\Controllers\\TempatController@update',
        'controller' => 'App\\Http\\Controllers\\TempatController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tempatusaha.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'tempatusaha/{tempatusaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tempatusaha',
        ),
        'as' => 'tempatusaha.destroy',
        'uses' => 'App\\Http\\Controllers\\TempatController@destroy',
        'controller' => 'App\\Http\\Controllers\\TempatController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::84XE1gELA1dk1K9L' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/neraca',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@neracaStore',
        'controller' => 'App\\Http\\Controllers\\TagihanController@neracaStore',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::84XE1gELA1dk1K9L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GvzWRPyr8h6DJmgV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/neraca',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@neraca',
        'controller' => 'App\\Http\\Controllers\\TagihanController@neraca',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::GvzWRPyr8h6DJmgV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f6TVnnpUHRWAu2n6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/manual/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@manual',
        'controller' => 'App\\Http\\Controllers\\TagihanController@manual',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::f6TVnnpUHRWAu2n6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5FAPYZESwJcII0cK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/sinkronisasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":594:{@2i6OiIVsj5U5CtGuung+W1vkGhNnlzT8Jx8lJslCurY=.a:5:{s:3:"use";a:0:{}s:8:"function";s:381:"function(\\Illuminate\\Http\\Request $request){
        if($request->ajax()){
            try{
                \\Artisan::call(\'cron:tagihan\');
                return \\response()->json([\'success\' => \'Sinkronisasi Sukses\']);
            }
            catch(\\Exception $e){
                return \\response()->json([\'errors\' => \'Oops! Sinkronisasi Gagal\']);
            }
        }
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed6c00000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::5FAPYZESwJcII0cK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zmRdelKaBIeRIEXY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/pemberitahuan/{blok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@pemberitahuan',
        'controller' => 'App\\Http\\Controllers\\TagihanController@pemberitahuan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::zmRdelKaBIeRIEXY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::txPyMsmFb4d0zM5j' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/unpublish/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@unpublish',
        'controller' => 'App\\Http\\Controllers\\TagihanController@unpublish',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::txPyMsmFb4d0zM5j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9d9hHt9CztsplyCf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/pembayaran/{blok}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@pembayaran',
        'controller' => 'App\\Http\\Controllers\\TagihanController@pembayaran',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9d9hHt9CztsplyCf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zwixFBxmUsNgFslV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/periode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@periode',
        'controller' => 'App\\Http\\Controllers\\TagihanController@periode',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::zwixFBxmUsNgFslV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xCP3mohv580KmQsn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/tambah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@tambah',
        'controller' => 'App\\Http\\Controllers\\TagihanController@tambah',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xCP3mohv580KmQsn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::DHxWlHdHvEUzQ92u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/publish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@publish',
        'controller' => 'App\\Http\\Controllers\\TagihanController@publish',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::DHxWlHdHvEUzQ92u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YqDNHXwBVcoEPC3O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/publish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@publishStore',
        'controller' => 'App\\Http\\Controllers\\TagihanController@publishStore',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YqDNHXwBVcoEPC3O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::LVfgNYmzCKJ8LKv8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/pesan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@pesan',
        'controller' => 'App\\Http\\Controllers\\TagihanController@pesan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::LVfgNYmzCKJ8LKv8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ABtxAcaQH9Lp1brh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@reviewStore',
        'controller' => 'App\\Http\\Controllers\\TagihanController@reviewStore',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ABtxAcaQH9Lp1brh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::C3NJwAjxLyROlB6k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/review/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@review',
        'controller' => 'App\\Http\\Controllers\\TagihanController@review',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::C3NJwAjxLyROlB6k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::GT9sAl6hqsNTopb5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/notification',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@notification',
        'controller' => 'App\\Http\\Controllers\\TagihanController@notification',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::GT9sAl6hqsNTopb5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'listrik' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/listrik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@listrik',
        'controller' => 'App\\Http\\Controllers\\TagihanController@listrik',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'listrik',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'airbersih' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/airbersih',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@airbersih',
        'controller' => 'App\\Http\\Controllers\\TagihanController@airbersih',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'airbersih',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mtbSKQFF1xwhyRpr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/listrik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@listrikUpdate',
        'controller' => 'App\\Http\\Controllers\\TagihanController@listrikUpdate',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::mtbSKQFF1xwhyRpr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YvurBOLWkWyjukUa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/airbersih',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@airbersihUpdate',
        'controller' => 'App\\Http\\Controllers\\TagihanController@airbersihUpdate',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::YvurBOLWkWyjukUa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::cs6spEkHjWfQUrB3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/print',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@print',
        'controller' => 'App\\Http\\Controllers\\TagihanController@print',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::cs6spEkHjWfQUrB3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::z1nnHjcJRcTZWBL5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@update',
        'controller' => 'App\\Http\\Controllers\\TagihanController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::z1nnHjcJRcTZWBL5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::l5wgezF5iXFgLVPK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/destroy/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@destroyEdit',
        'controller' => 'App\\Http\\Controllers\\TagihanController@destroyEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::l5wgezF5iXFgLVPK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ckqZ6yVBziTYwDjl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'uses' => 'App\\Http\\Controllers\\TagihanController@destroy',
        'controller' => 'App\\Http\\Controllers\\TagihanController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ckqZ6yVBziTYwDjl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tagihan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'as' => 'tagihan.index',
        'uses' => 'App\\Http\\Controllers\\TagihanController@index',
        'controller' => 'App\\Http\\Controllers\\TagihanController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tagihan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'as' => 'tagihan.create',
        'uses' => 'App\\Http\\Controllers\\TagihanController@create',
        'controller' => 'App\\Http\\Controllers\\TagihanController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tagihan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tagihan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'as' => 'tagihan.store',
        'uses' => 'App\\Http\\Controllers\\TagihanController@store',
        'controller' => 'App\\Http\\Controllers\\TagihanController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tagihan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/{tagihan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'as' => 'tagihan.show',
        'uses' => 'App\\Http\\Controllers\\TagihanController@show',
        'controller' => 'App\\Http\\Controllers\\TagihanController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tagihan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'tagihan/{tagihan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'as' => 'tagihan.edit',
        'uses' => 'App\\Http\\Controllers\\TagihanController@edit',
        'controller' => 'App\\Http\\Controllers\\TagihanController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tagihan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'tagihan/{tagihan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'as' => 'tagihan.update',
        'uses' => 'App\\Http\\Controllers\\TagihanController@update',
        'controller' => 'App\\Http\\Controllers\\TagihanController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'tagihan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'tagihan/{tagihan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tagihan',
        ),
        'as' => 'tagihan.destroy',
        'uses' => 'App\\Http\\Controllers\\TagihanController@destroy',
        'controller' => 'App\\Http\\Controllers\\TagihanController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::SRxWn0tHYHHFsckn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pemakaian',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pemakaian',
        ),
        'uses' => 'App\\Http\\Controllers\\PemakaianController@index',
        'controller' => 'App\\Http\\Controllers\\PemakaianController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::SRxWn0tHYHHFsckn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1V9VToo6GMmAdi0c' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pemakaian/{fasilitas}/{bulan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pemakaian',
        ),
        'uses' => 'App\\Http\\Controllers\\PemakaianController@fasilitas',
        'controller' => 'App\\Http\\Controllers\\PemakaianController@fasilitas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::1V9VToo6GMmAdi0c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Bp5VLRI1G9uIROfr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/tahunan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'uses' => 'App\\Http\\Controllers\\PendapatanController@tahunan',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@tahunan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Bp5VLRI1G9uIROfr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::nU8vk0lfGxNbhy92' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/bulanan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'uses' => 'App\\Http\\Controllers\\PendapatanController@bulanan',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@bulanan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::nU8vk0lfGxNbhy92',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.index',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@index',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@index',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.create',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@create',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@create',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'rekap/pendapatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.store',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@store',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@store',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.show',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@show',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@show',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.edit',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@edit',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@edit',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.update',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@update',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@update',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'pendapatan.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'rekap/pendapatan/{pendapatan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:pendapatan',
        ),
        'as' => 'pendapatan.destroy',
        'uses' => 'App\\Http\\Controllers\\PendapatanController@destroy',
        'controller' => 'App\\Http\\Controllers\\PendapatanController@destroy',
        'namespace' => NULL,
        'prefix' => '/rekap',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::CrJ0RBPiduSdskPX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datausaha/penghapusan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@penghapusan',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@penghapusan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::CrJ0RBPiduSdskPX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eXyxLq2Tkk7rKYZf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datausaha/bongkaran',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@bongkaran',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@bongkaran',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::eXyxLq2Tkk7rKYZf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yEe2LxTKMNCpBOld' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datausaha/tunggakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@tunggakan',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@tunggakan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yEe2LxTKMNCpBOld',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'datausaha.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datausaha',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'as' => 'datausaha.index',
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@index',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'datausaha.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datausaha/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'as' => 'datausaha.create',
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@create',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'datausaha.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'datausaha',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'as' => 'datausaha.store',
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@store',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'datausaha.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datausaha/{datausaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'as' => 'datausaha.show',
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@show',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'datausaha.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datausaha/{datausaha}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'as' => 'datausaha.edit',
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@edit',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'datausaha.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'datausaha/{datausaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'as' => 'datausaha.update',
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@update',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'datausaha.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'datausaha/{datausaha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:datausaha',
        ),
        'as' => 'datausaha.destroy',
        'uses' => 'App\\Http\\Controllers\\DataUsahaController@destroy',
        'controller' => 'App\\Http\\Controllers\\DataUsahaController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KkmheCf9MsSgUj2B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@index',
        'controller' => 'App\\Http\\Controllers\\TarifController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KkmheCf9MsSgUj2B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::ZwPv07ettsSrI7JQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/keamananipk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@keamananipk',
        'controller' => 'App\\Http\\Controllers\\TarifController@keamananipk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::ZwPv07ettsSrI7JQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TECY3VAAvc7PJyxK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/kebersihan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@kebersihan',
        'controller' => 'App\\Http\\Controllers\\TarifController@kebersihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::TECY3VAAvc7PJyxK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aWhsM4ZIZ2EV8vrx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/airkotor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@airkotor',
        'controller' => 'App\\Http\\Controllers\\TarifController@airkotor',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::aWhsM4ZIZ2EV8vrx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kpNhER2h70hSZjDj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/lain',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@lain',
        'controller' => 'App\\Http\\Controllers\\TarifController@lain',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::kpNhER2h70hSZjDj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lAIQkCaK8atee1u6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/tarif/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@store',
        'controller' => 'App\\Http\\Controllers\\TarifController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::lAIQkCaK8atee1u6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::B8siwiSH72H22Dp3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/edit/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@edit',
        'controller' => 'App\\Http\\Controllers\\TarifController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::B8siwiSH72H22Dp3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KbP8BcwGyXj3AiGo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/tarif/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@update',
        'controller' => 'App\\Http\\Controllers\\TarifController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KbP8BcwGyXj3AiGo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::86JqXL8OhpOFISHR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/tarif/destroy/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:tarif',
        ),
        'uses' => 'App\\Http\\Controllers\\TarifController@destroy',
        'controller' => 'App\\Http\\Controllers\\TarifController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::86JqXL8OhpOFISHR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FfWfLuVmxksA516j' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@index',
        'controller' => 'App\\Http\\Controllers\\AlatController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::FfWfLuVmxksA516j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HaRdVjSXvw2sg3KF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/air',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@air',
        'controller' => 'App\\Http\\Controllers\\AlatController@air',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::HaRdVjSXvw2sg3KF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Kyqkm3Z7dBDt777a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/alatmeter/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@store',
        'controller' => 'App\\Http\\Controllers\\AlatController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Kyqkm3Z7dBDt777a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8mw9TleSfzEVx4Xp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/edit/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@edit',
        'controller' => 'App\\Http\\Controllers\\AlatController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::8mw9TleSfzEVx4Xp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0HVzbwjPnGZilnGo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/alatmeter/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@update',
        'controller' => 'App\\Http\\Controllers\\AlatController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0HVzbwjPnGZilnGo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::lE3iP5NJAkJP4ruR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/destroy/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@destroy',
        'controller' => 'App\\Http\\Controllers\\AlatController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::lE3iP5NJAkJP4ruR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::eSJxcaaiS2xjLJ57' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/alatmeter/qr/{fasilitas}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:alatmeter',
        ),
        'uses' => 'App\\Http\\Controllers\\AlatController@qr',
        'controller' => 'App\\Http\\Controllers\\AlatController@qr',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::eSJxcaaiS2xjLJ57',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AwXaRDhrHNkksXEs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/harilibur',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@index',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AwXaRDhrHNkksXEs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::oznlCEzuDlrR31CN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/harilibur/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@store',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::oznlCEzuDlrR31CN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::aI3A6yln0rvO3iEg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/harilibur/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@edit',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::aI3A6yln0rvO3iEg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ud5J2DirbGodlbwo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/harilibur/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@update',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Ud5J2DirbGodlbwo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::723VbUOfuzO9Oxhv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/harilibur/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:harilibur',
        ),
        'uses' => 'App\\Http\\Controllers\\HariLiburController@destroy',
        'controller' => 'App\\Http\\Controllers\\HariLiburController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::723VbUOfuzO9Oxhv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::yxf4WajUm7GxaoxR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/blok',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@index',
        'controller' => 'App\\Http\\Controllers\\BlokController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::yxf4WajUm7GxaoxR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tiL50ldnw4gJ94dq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/blok/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@store',
        'controller' => 'App\\Http\\Controllers\\BlokController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tiL50ldnw4gJ94dq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::f3BTBOs06QAsy8N5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/blok/edit/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@edit',
        'controller' => 'App\\Http\\Controllers\\BlokController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::f3BTBOs06QAsy8N5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4WowXr6Py6JiwMb8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/blok/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@update',
        'controller' => 'App\\Http\\Controllers\\BlokController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4WowXr6Py6JiwMb8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::0jTvthuW51lPS9qu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/blok/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:blok',
        ),
        'uses' => 'App\\Http\\Controllers\\BlokController@destroy',
        'controller' => 'App\\Http\\Controllers\\BlokController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::0jTvthuW51lPS9qu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::vmInFSfhd5pTvLV6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'utilities/simulasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:simulasi',
        ),
        'uses' => 'App\\Http\\Controllers\\SimulasiController@index',
        'controller' => 'App\\Http\\Controllers\\SimulasiController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::vmInFSfhd5pTvLV6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KNkpR17ytXT6egkA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'utilities/simulasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:simulasi',
        ),
        'uses' => 'App\\Http\\Controllers\\SimulasiController@store',
        'controller' => 'App\\Http\\Controllers\\SimulasiController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::KNkpR17ytXT6egkA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Fsg7lo1wm3SflPgs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master/kasir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@kasir',
        'controller' => 'App\\Http\\Controllers\\MasterController@kasir',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Fsg7lo1wm3SflPgs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::4K5lJTUHmwE3mLRr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'master/kasir/restore/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@kasirRestore',
        'controller' => 'App\\Http\\Controllers\\MasterController@kasirRestore',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::4K5lJTUHmwE3mLRr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::pcYA79U2bjOdF7PU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'master/kasir/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@kasirEdit',
        'controller' => 'App\\Http\\Controllers\\MasterController@kasirEdit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::pcYA79U2bjOdF7PU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::x7Pb98S75erhpxgf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'master/kasir/struk/{struk}/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:master',
        ),
        'uses' => 'App\\Http\\Controllers\\MasterController@cetakStruk',
        'controller' => 'App\\Http\\Controllers\\MasterController@cetakStruk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::x7Pb98S75erhpxgf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::hpjgZOnxtIjvdYBw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::hpjgZOnxtIjvdYBw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::MNDFuxjDhEkp1Af0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/destroy/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::MNDFuxjDhEkp1Af0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9yabRBW5kugwNYw6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/reset/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@reset',
        'controller' => 'App\\Http\\Controllers\\UserController@reset',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9yabRBW5kugwNYw6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::RjleNt8P3Cy6kvm4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{id}/otoritas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@etoritas',
        'controller' => 'App\\Http\\Controllers\\UserController@etoritas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::RjleNt8P3Cy6kvm4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Rn3zKC3OCqoMGlx6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/otoritas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@otoritas',
        'controller' => 'App\\Http\\Controllers\\UserController@otoritas',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::Rn3zKC3OCqoMGlx6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3DQ8wiqny5Ha9du4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/manajer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@manajer',
        'controller' => 'App\\Http\\Controllers\\UserController@manajer',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3DQ8wiqny5Ha9du4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NvwjrhgKldAuMhOx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/keuangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@keuangan',
        'controller' => 'App\\Http\\Controllers\\UserController@keuangan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::NvwjrhgKldAuMhOx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TfJJDbd2DB2DKLRw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/kasir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@kasir',
        'controller' => 'App\\Http\\Controllers\\UserController@kasir',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::TfJJDbd2DB2DKLRw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::7aHYBbVWz1TfBbwo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/nasabah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@nasabah',
        'controller' => 'App\\Http\\Controllers\\UserController@nasabah',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::7aHYBbVWz1TfBbwo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.index',
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.create',
        'uses' => 'App\\Http\\Controllers\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\UserController@create',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.store',
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.show',
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{user}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.edit',
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'user/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.update',
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'user.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'user/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:user',
        ),
        'as' => 'user.destroy',
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::78VmUfTCgi8v7EqW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'log',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:log',
          2 => 'log',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":1377:{@KMZ5O5wWSJhcO47IaYWZ9J7BnYpmFXM7E7Uz1pmiBMU=.a:5:{s:3:"use";a:0:{}s:8:"function";s:1163:"function(\\Illuminate\\Http\\Request $request){
        if($request->ajax())
        {
            $data = \\App\\Models\\LoginLog::orderBy(\'id\',\'desc\');
            return \\DataTables::of($data)
                    ->addIndexColumn()
                    ->editColumn(\'ktp\', function ($ktp) {
                        if ($ktp->ktp == NULL) return \'<span class="text-center"><i class="fas fa-times fa-sm"></i></span>\';
                        else return $ktp->ktp;
                    })
                    ->editColumn(\'hp\', function ($hp) {
                        if ($hp->hp == NULL) return \'<span class="text-center"><i class="fas fa-times fa-sm"></i></span>\';
                        else return $hp->hp;
                    })
                    ->editColumn(\'created_at\', function ($user) {
                        return [
                           \'display\' => $user->created_at->format(\'d-m-Y H:i:s\'),
                           \'timestamp\' => $user->created_at->timestamp
                        ];
                     })
                    ->rawColumns([\'ktp\',\'hp\'])
                    ->make(true);
        }
        return \\view(\'log.index\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed76f0000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::78VmUfTCgi8v7EqW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::FYUNnRqREBo4uWhf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/blok',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariBlok',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariBlok',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::FYUNnRqREBo4uWhf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::bNOQhfkrC52O9fjN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/nasabah',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariNasabah',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariNasabah',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::bNOQhfkrC52O9fjN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::g68Sy4gN8TByqWiY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alamat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlamat',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlamat',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::g68Sy4gN8TByqWiY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::AzGfRA5Z8HldLjn6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alamat/kosong',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlamatKosong',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlamatKosong',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::AzGfRA5Z8HldLjn6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tmWD3Gahk2CWvpxx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alatlistrik',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlatListrik',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlatListrik',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tmWD3Gahk2CWvpxx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::3zXqJmwPvNxEwwl8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/alatair',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAlatAir',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAlatAir',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::3zXqJmwPvNxEwwl8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::M3fvRT6gwyPRAcQs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/tagihan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariTagihan',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariTagihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::M3fvRT6gwyPRAcQs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::c9vZpWmACmcd6Lrm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/listrik/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariListrik',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariListrik',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::c9vZpWmACmcd6Lrm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::UyJvYsm04pFrZbsh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/airbersih/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAirBersih',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAirBersih',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::UyJvYsm04pFrZbsh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::skoW2uY5rKLUnD66' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/keamananipk/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariKeamananIpk',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariKeamananIpk',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::skoW2uY5rKLUnD66',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::tT46gzQkbgVNpNQj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/kebersihan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariKebersihan',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariKebersihan',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::tT46gzQkbgVNpNQj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9Tl8NCeIFGyuEPoJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/airkotor/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariAirKotor',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariAirKotor',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::9Tl8NCeIFGyuEPoJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::J5YPU3p4PRawfESi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/lain/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariLain',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariLain',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::J5YPU3p4PRawfESi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::98sLsMZlgYktr70h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cari/tagihan/{fasilitas}/{kontrol}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'ceklogin:human',
        ),
        'uses' => 'App\\Http\\Controllers\\SearchController@cariTagihanku',
        'controller' => 'App\\Http\\Controllers\\SearchController@cariTagihanku',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::98sLsMZlgYktr70h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gPca4IixUyKIKrWY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'work',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\WorkController@work',
        'controller' => 'App\\Http\\Controllers\\WorkController@work',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::gPca4IixUyKIKrWY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::n0nfFiPPKIku8R1m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'work/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\WorkController@update',
        'controller' => 'App\\Http\\Controllers\\WorkController@update',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::n0nfFiPPKIku8R1m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xtQpdrdV9JhcaS8k' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DownloadController@index',
        'controller' => 'App\\Http\\Controllers\\DownloadController@index',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::xtQpdrdV9JhcaS8k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::1dnjbFKynhsDZQGv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'optimize.p3cmaster',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'C:32:"Opis\\Closure\\SerializableClosure":352:{@PKp/rNzmWmLusPcKQHRu5lgn6ymvDBAkS7fbcQ4kLTU=.a:5:{s:3:"use";a:0:{}s:8:"function";s:139:"function(){
    \\Artisan::call(\'optimize\');
    \\Artisan::call(\'cron:log\');
    \\Artisan::call(\'cron:login\');
    return \\view(\'danger\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000007d9ed7760000000009fff767";}}',
        'namespace' => NULL,
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::1dnjbFKynhsDZQGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
