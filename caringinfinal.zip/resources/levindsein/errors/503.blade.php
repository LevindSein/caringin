@extends('errors::minimal')

@section('title', __('Maintenance | Service Unavailable'))
@section('code', '503')
@section('message', __('Maintenance'))
