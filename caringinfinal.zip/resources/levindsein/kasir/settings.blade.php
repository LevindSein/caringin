<?php    
    echo "<script>alert('settings under construction')</script>";
?>