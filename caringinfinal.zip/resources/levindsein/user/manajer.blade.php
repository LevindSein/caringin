<div class="table-responsive">
    <table 
        class="table table-bordered" 
        id="userManajer"
        cellspacing="0"
        width="100%"
        style="font-size:0.75rem;">
        <thead>
            <tr>
                <th style="max-width:10px;">No.</th>
                <th>Username</th>
                <th>Nama</th>
                <th>KTP</th>
                <th>HP</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
    </table>
</div>